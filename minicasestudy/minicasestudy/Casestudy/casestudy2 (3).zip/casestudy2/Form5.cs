﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace casestudy2
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        foodEntities ob = new foodEntities();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                customer o = new customer();

                o.customer_name = textBox1.Text;
                o.contact_number = textBox2.Text;
                o.rcity = textBox3.Text;
                o.address = textBox4.Text;
                o.username = textBox5.Text;
                o.pwdwrd = textBox6.Text;
                ob.customers.Add(o); //insert
                int noOfRows = ob.SaveChanges();//save this datbase table
                if (noOfRows > 0)
                {
                    MessageBox.Show("successful");
                    Form1 a = new Form1();
                    a.Show();
                }

                else
                {
                    MessageBox.Show("Sign Up is not successful");

                }

            }
            catch (Exception u)
            {
                MessageBox.Show(u.Message);

            }
        }

        private void textBox5_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox5.Text))
            {
                e.Cancel = true;
                textBox5.Focus();
                errorProvider1.SetError(textBox5, "please enter your name");

            }
            else
            {
                e.Cancel = false;
                textBox5.Focus();
                errorProvider1.SetError(textBox5, "");
            }

        }
    }
}

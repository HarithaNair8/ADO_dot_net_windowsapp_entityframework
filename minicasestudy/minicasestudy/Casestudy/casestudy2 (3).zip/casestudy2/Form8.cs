﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace casestudy2
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        foodEntities ob = new foodEntities();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                var resultValue = from r in ob.restaurants
                                  where r.rcity == textBox1.Text
                                  select r;
                dataGridView1.DataSource = resultValue.ToList();

            }
            catch (Exception y)
            {
                MessageBox.Show(y.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var resultValue = from r in ob.fooditems

                                  select r;
                dataGridView2.DataSource = resultValue.ToList();

            }
            catch (Exception y)
            {
                MessageBox.Show(y.Message);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form8_Load(object sender, EventArgs e)
        {
            DataGridViewCheckBoxColumn chkbox = new DataGridViewCheckBoxColumn();
            chkbox.HeaderText = "Select";
            chkbox.Width = 25;
            chkbox.Name = "dgvchkbox";
            chkbox.DefaultCellStyle.BackColor = Color.Red;
            dataGridView2.Columns.Insert(0, chkbox);

            DataGridViewCheckBoxColumn chkboxx = new DataGridViewCheckBoxColumn();
            chkboxx.HeaderText = "Select";
            chkboxx.Width = 25;
            chkboxx.Name = "dgvchkbox";
            chkboxx.DefaultCellStyle.BackColor = Color.Red;
            dataGridView1.Columns.Insert(0, chkboxx);



        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("food_id");
            dt.Columns.Add("food_name");
            dt.Columns.Add("price_per_unit");
            dt.Columns.Add("order_food");


            foreach (DataGridViewRow drv in dataGridView2.Rows)
            {
                bool chkboxselect = Convert.ToBoolean(drv.Cells["dgvchkbox"].Value);
                if (chkboxselect)
                {
                    dt.Rows.Add(drv.Cells[2].Value, drv.Cells[3].Value, drv.Cells[4].Value);
                    drv.DefaultCellStyle.BackColor = Color.Gray;
                    drv.DefaultCellStyle.ForeColor = Color.Aqua;
                }
                dataGridView3.DataSource = dt;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            decimal sum = 0;
            for (int i = 0; i < dataGridView3.Rows.Count; ++i)
            {
                sum += Convert.ToDecimal(dataGridView3.Rows[i].Cells[1].Value);
            }
            // MessageBox.Show(sum.ToString());
            // textBox1.Show(sum.ToString());
            //Control.Show(sum.ToString)
            textBox2.Text = sum.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                orderstatu o = new orderstatu();
                o.grandtotal = Convert.ToDecimal(textBox2.Text);
                o.customer_id = Convert.ToInt32(textBox3.Text);
                o.payment = comboBox1.Text;
                ob.orderstatus.Add(o);//insert
                int noOfRows = ob.SaveChanges();//save this datbase table
                if (noOfRows > 0)
                    MessageBox.Show(" Order Confirmed");
                else
                    MessageBox.Show("Order is not successful");
            }
            catch (Exception u)
            {
                MessageBox.Show(u.Message);

            }

        }

        private void signOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void knowYourCustIDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 a = new Form7();
            a.Show();
        }
    }
}

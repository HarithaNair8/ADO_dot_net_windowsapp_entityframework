﻿using System;
using System.Linq;
using Xunit;
using casestudy2;
namespace Testproject
{
    public class UnitTest1
    {
        foodEntities ob = new foodEntities();
        [Fact]
        public void TestMethod1()
        {
            Userpassword o = new Userpassword();
            Restaurant a = new Restaurant();
            Customer b = new Customer();
            Fooditem c = new Fooditem();
            Orderstatu d = new Orderstatu();

        }
    }
}
